
package it.csa.patient.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.csa.patient.Model.Patient;
import it.csa.patient.Repository.PatientRepository;

@RestController
@RequestMapping("/api/patient")
public class PatientController {

	
	@Autowired
	PatientRepository patientRepository;
	
	@PostMapping
	public boolean Insert( @RequestBody Patient patient) {
		
		
		try
		
		{	
			patientRepository.save(patient);
		}
		catch(Exception ex)
		{
			return false;
		}
		
		
		
	   return true;
	}
	
}
