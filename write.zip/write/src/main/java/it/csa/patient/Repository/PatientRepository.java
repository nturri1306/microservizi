
package it.csa.patient.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import it.csa.patient.Model.Patient;

public interface PatientRepository extends JpaRepository<Patient, Long> {

	    
	
}

