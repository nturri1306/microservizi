package it.csa.patient.write;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WriteApplicationTests {

	@Test
	void contextLoads() {
	}

}
